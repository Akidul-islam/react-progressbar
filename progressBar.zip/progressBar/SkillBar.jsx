import React, { useEffect, useState, useRef } from 'react';
import './skillBar.css';
const SkillBar = () => {
  // MY ARRAY
  const barComponent = [
           //this my array width
    { id: 1, title: "Frontend", width: 40 },
    { id: 2, title: "UI/UX", width: 70 },
    { id: 3, title: "WEB DESIGN", width: 60 },
    { id: 4, title: "GRAPHICE", width: 80 },
    { id: 5, title: "VIDEO EDITING", width: 70 },
  ];
  const styleWidth = (width) => {
    const innerBar ={
        position: "relative",
        width: `${width}%`,
        height: "100%",
        borderRadius: "0.2em",
        background: "rgba(182, 63, 136, 0.749)",
        // animation: "width 0.5s linear",
    };
    return innerBar;
  }
const intervalId = useRef();

const [count, setCount] = useState([]);

useEffect(() =>{
  // i was appled this conddition but it was not work properly.
  // only (count <= 40) this condition work.what is the problem here i can't figuer out. 
barComponent.forEach(item => {
  // if(count >= item.width){
  //   clearInterval(intervalId.current);
  // }
  setCount(prev => ({
    ...prev,
    [item.id]: item.width
  }));
});
},[])

useEffect(() => {
  count.forEach(item => {
    intervalId.current = setInterval(() =>{
      setCount({
        
      })
    }, 200)
  })
  
  return () =>{
  clearInterval(intervalId.current);
  }
},[]);

// useEffect(() => {
//   intervalId.current = setInterval(() =>{
//     setCount(prev => prev + 1)
//   }, 200)
//   return () =>{
//   clearInterval(intervalId.current);
//   }
// },[]);

  return (
        barComponent.map(bar =>{
          return <div key={bar.id} className="skills__container">
                    <h3>{bar.title}</h3>
                    <article className='skills__bar'>
                      <div style={styleWidth(count)}
                            className="inner__bar">
                          <span>{`${count}%`}</span>
                      </div>
                  </article>
                </div>
          
          })
  )
}

export default SkillBar;
